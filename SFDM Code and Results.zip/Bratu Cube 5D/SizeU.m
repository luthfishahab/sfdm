function size_u = SizeU(n)
    size_u = 0;
    for i1 = 1:n/2
        for i2 = i1:n/2
            for i3 = i2:n/2
                for i4 = i3:n/2
                    for i5 = i4:n/2
                        size_u = size_u + 1;
                    end
                end
            end
        end
    end
end