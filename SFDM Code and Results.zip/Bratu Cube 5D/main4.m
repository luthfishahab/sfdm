clc
clear
close all

%% Figure n=50 and ball

figure

A = readmatrix('all_C_and_u_max FD n=50.csv');
x = [0; A(:,1)];
y = [0; A(:,2)];
plot(x, y, "LineWidth", 1.5)
hold on
max_old = max(x);

A = readmatrix('all_C_and_u_max FD d=5 n=1000000.csv');
x = [0; A(:,1)];
x = x*max_old/max(x);
y = [0; A(:,2)];
plot(x, y, "LineWidth", 1.5, "LineStyle", "--")
hold on

legend('SFDM n=50', 'FDM Ball n=10^6','Location','southwest')
xlabel('$\lambda$', 'Interpreter', 'latex')
ylabel('$||u||_{\infty}$', 'Interpreter', 'latex')

xlim([0 16])
ylim([0 16])
xticks(0:2:16)
yticks(0:2:16)
grid on

x0=100;
y0=100;
width=400;
height=300;
set(gcf,'position',[x0,y0,width,height])

%% Figure n=10, ..., 50

figure

for n = 10:10:50
    file_name = "all_C_and_u_max FD n=" + num2str(n) + ".csv";
    A = readmatrix(file_name);
    x = [0; A(:,1)];
    y = [0; A(:,2)];
    plot(x, y, "LineWidth", 1)
    hold on
end

xlabel('$\lambda$', 'Interpreter', 'latex')
ylabel('$||u||_{\infty}$', 'Interpreter', 'latex')

xlim([0 16])
ylim([0 16])
xticks(0:2:16)
yticks(0:2:16)
grid on

x0=100;
y0=100;
width=400;
height=300;
set(gcf,'position',[x0,y0,width,height])

%% First Turning Point

A = readmatrix('all_C_and_u_max FD n=50 max_lambda.csv');
all_C = A(:, 1);
all_u_max = A(:, 2);

y2 = 2.1:0.000001:2.3;
x2 = spline(all_u_max(1:101), all_C(1:101), y2);
max_lambda = sprintf('%.9f', max(x2))