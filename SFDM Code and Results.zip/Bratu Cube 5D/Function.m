function F = Function(u, C, n, i1, i2, i3, i4, i5, i6, i7, i8, i9, i10, i11)
    h = 1/n;
    
    U = [u; 0];

    laplacian = -10*U(i1) + U(i2) + U(i3) + U(i4) + U(i5) + U(i6) + U(i7) + U(i8) + U(i9) + U(i10) + U(i11);
    laplacian = laplacian/(h^2);
    
    F = laplacian + C*exp(U(i1));
end