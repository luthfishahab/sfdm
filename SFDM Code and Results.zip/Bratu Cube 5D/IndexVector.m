function [i1, i2, i3, i4, i5, i6, i7, i8, i9, i10, i11] = IndexVector(n, size_u)
    A = zeros(size_u, 4);
    p = 0;
    for i = 1:n/2
        for j = i:n/2
            for k = j:n/2
                for l = k:n/2
                    for m = l:n/2
                        p = p + 1;
                        A(p,1) = i;
                        A(p,2) = j;
                        A(p,3) = k;
                        A(p,4) = l;
                        A(p,5) = m;
                        A(p,6) = i*10^12+j*10^9+k*10^6+l*10^3+m;
                    end
                end
            end
        end
    end
    
    % 3-point stencil index
    i1 = zeros(size_u,1);
    i2 = zeros(size_u,1);
    i3 = zeros(size_u,1);
    i4 = zeros(size_u,1);
    i5 = zeros(size_u,1);
    i6 = zeros(size_u,1);
    i7 = zeros(size_u,1);
    i8 = zeros(size_u,1);
    i9 = zeros(size_u,1);
    i10 = zeros(size_u,1);
    i11 = zeros(size_u,1);
    p = 0;
    for i = 1:n/2
        disp(['i = ', num2str(i)])
        for j = i:n/2
            for k = j:n/2
                for l = k:n/2
                    for m = l:n/2
                            p = p + 1;
                            
                            % Find index i,j,k,l,m
                            temp = i*10^12+j*10^9+k*10^6+l*10^3+m;
                            index = find(A(:,6) == temp);
                            if size(index,1) == 0
                                i1(p) = size_u+1;
                            else
                                i1(p) = index;
                            end
                
                            % Find index i+1,j,k,l,m
                            a = i+1;
                            b = j;
                            c = k;
                            d = l;
                            e = m;
                            a = min([a n-a]);
                            b = min([b n-b]);
                            c = min([c n-c]);
                            d = min([d n-d]);
                            e = min([e n-e]);
                            f = sort([a b c d e]);
                            a = f(1);
                            b = f(2);
                            c = f(3);
                            d = f(4);
                            e = f(5);
                            temp = a*10^12+b*10^9+c*10^6+d*10^3+e;
                            index = find(A(:,6) == temp);
                            if size(index,1) == 0
                                i2(p) = size_u+1;
                            else
                                i2(p) = index;
                            end
                
                            % Find index i-1,j,k,l,m
                            a = i-1;
                            b = j;
                            c = k;
                            d = l;
                            e = m;
                            a = min([a n-a]);
                            b = min([b n-b]);
                            c = min([c n-c]);
                            d = min([d n-d]);
                            e = min([e n-e]);
                            f = sort([a b c d e]);
                            a = f(1);
                            b = f(2);
                            c = f(3);
                            d = f(4);
                            e = f(5);
                            temp = a*10^12+b*10^9+c*10^6+d*10^3+e;
                            index = find(A(:,6) == temp);
                            if size(index,1) == 0
                                i3(p) = size_u+1;
                            else
                                i3(p) = index;
                            end
                
                            % Find index i,j+1,k,l,m
                            a = i;
                            b = j+1;
                            c = k;
                            d = l;
                            e = m;
                            a = min([a n-a]);
                            b = min([b n-b]);
                            c = min([c n-c]);
                            d = min([d n-d]);
                            e = min([e n-e]);
                            f = sort([a b c d e]);
                            a = f(1);
                            b = f(2);
                            c = f(3);
                            d = f(4);
                            e = f(5);
                            temp = a*10^12+b*10^9+c*10^6+d*10^3+e;
                            index = find(A(:,6) == temp);
                            if size(index,1) == 0
                                i4(p) = size_u+1;
                            else
                                i4(p) = index;
                            end
                
                            % Find index i,j-1,k,l,m
                            a = i;
                            b = j-1;
                            c = k;
                            d = l;
                            e = m;
                            a = min([a n-a]);
                            b = min([b n-b]);
                            c = min([c n-c]);
                            d = min([d n-d]);
                            e = min([e n-e]);
                            f = sort([a b c d e]);
                            a = f(1);
                            b = f(2);
                            c = f(3);
                            d = f(4);
                            e = f(5);
                            temp = a*10^12+b*10^9+c*10^6+d*10^3+e;
                            index = find(A(:,6) == temp);
                            if size(index,1) == 0
                                i5(p) = size_u+1;
                            else
                                i5(p) = index;
                            end
                
                            % Find index i,j,k+1,l,m
                            a = i;
                            b = j;
                            c = k+1;
                            d = l;
                            e = m;
                            a = min([a n-a]);
                            b = min([b n-b]);
                            c = min([c n-c]);
                            d = min([d n-d]);
                            e = min([e n-e]);
                            f = sort([a b c d e]);
                            a = f(1);
                            b = f(2);
                            c = f(3);
                            d = f(4);
                            e = f(5);
                            temp = a*10^12+b*10^9+c*10^6+d*10^3+e;
                            index = find(A(:,6) == temp);
                            if size(index,1) == 0
                                i6(p) = size_u+1;
                            else
                                i6(p) = index;
                            end
                
                            % Find index i,j,k-1,l,m
                            a = i;
                            b = j;
                            c = k-1;
                            d = l;
                            e = m;
                            a = min([a n-a]);
                            b = min([b n-b]);
                            c = min([c n-c]);
                            d = min([d n-d]);
                            e = min([e n-e]);
                            f = sort([a b c d e]);
                            a = f(1);
                            b = f(2);
                            c = f(3);
                            d = f(4);
                            e = f(5);
                            temp = a*10^12+b*10^9+c*10^6+d*10^3+e;
                            index = find(A(:,6) == temp);
                            if size(index,1) == 0
                                i7(p) = size_u+1;
                            else
                                i7(p) = index;
                            end
            
                            % Find index i,j,k,l+1,m
                            a = i;
                            b = j;
                            c = k;
                            d = l+1;
                            e = m;
                            a = min([a n-a]);
                            b = min([b n-b]);
                            c = min([c n-c]);
                            d = min([d n-d]);
                            e = min([e n-e]);
                            f = sort([a b c d e]);
                            a = f(1);
                            b = f(2);
                            c = f(3);
                            d = f(4);
                            e = f(5);
                            temp = a*10^12+b*10^9+c*10^6+d*10^3+e;
                            index = find(A(:,6) == temp);
                            if size(index,1) == 0
                                i8(p) = size_u+1;
                            else
                                i8(p) = index;
                            end
            
                            % Find index i,j,k,l-1,m
                            a = i;
                            b = j;
                            c = k;
                            d = l-1;
                            e = m;
                            a = min([a n-a]);
                            b = min([b n-b]);
                            c = min([c n-c]);
                            d = min([d n-d]);
                            e = min([e n-e]);
                            f = sort([a b c d e]);
                            a = f(1);
                            b = f(2);
                            c = f(3);
                            d = f(4);
                            e = f(5);
                            temp = a*10^12+b*10^9+c*10^6+d*10^3+e;
                            index = find(A(:,6) == temp);
                            if size(index,1) == 0
                                i9(p) = size_u+1;
                            else
                                i9(p) = index;
                            end

                            % Find index i,j,k,l,m+1
                            a = i;
                            b = j;
                            c = k;
                            d = l;
                            e = m+1;
                            a = min([a n-a]);
                            b = min([b n-b]);
                            c = min([c n-c]);
                            d = min([d n-d]);
                            e = min([e n-e]);
                            f = sort([a b c d e]);
                            a = f(1);
                            b = f(2);
                            c = f(3);
                            d = f(4);
                            e = f(5);
                            temp = a*10^12+b*10^9+c*10^6+d*10^3+e;
                            index = find(A(:,6) == temp);
                            if size(index,1) == 0
                                i10(p) = size_u+1;
                            else
                                i10(p) = index;
                            end

                            % Find index i,j,k,l,m-1
                            a = i;
                            b = j;
                            c = k;
                            d = l;
                            e = m-1;
                            a = min([a n-a]);
                            b = min([b n-b]);
                            c = min([c n-c]);
                            d = min([d n-d]);
                            e = min([e n-e]);
                            f = sort([a b c d e]);
                            a = f(1);
                            b = f(2);
                            c = f(3);
                            d = f(4);
                            e = f(5);
                            temp = a*10^12+b*10^9+c*10^6+d*10^3+e;
                            index = find(A(:,6) == temp);
                            if size(index,1) == 0
                                i11(p) = size_u+1;
                            else
                                i11(p) = index;
                            end
                    end
                end
            end
        end
    end
end