clc
clear
close all

% Parameter
n = 10; % choose: 10, 20, 30, 40, 50
h = 1/n;

% Size of u
size_u = SizeU(n);

% Index vector
tic
[i1, i2, i3, i4, i5, i6, i7, i8, i9, i10, i11] = IndexVector(n, size_u);
toc

% Solve
size_bifurcation = 160;
all_C = zeros(size_bifurcation, 1);
all_u_max = zeros(size_bifurcation, 1);

% Initial Values
u_and_C = zeros(size_u, 1);

j = 1;
for i = 0.1 : 0.1 : 16
    u_max = i;
    disp(' ');
    disp(['u_max = ', num2str(u_max)])

    tic
    [u_and_C, Err] = NewtonMethod_u(u_and_C, u_max, n, i1, i2, i3, i4, i5, i6, i7, i8, i9, i10, i11);
    toc
    
        C = u_and_C(end);
        u = u_and_C;
        u(end) = u_max;
    
    all_C(j) = C;
    all_u_max(j) = u_max;

    j = j + 1;
end

filename1 = "all_C_and_u_max FD n=" + n + ".csv";
writematrix([all_C all_u_max], filename1, 'Delimiter', ';');

figure
plot([0; all_C], [0; all_u_max])