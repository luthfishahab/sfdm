clc
clear
close all

% Parameter
n = 10; % choose: 10, 20, 30, ..., 300
h = 1/n;

% Size of u
size_u = 0;
for i = 1:n/2
    for j = i:n/2
        for k = j:n/2
            size_u = size_u + 1;
        end
    end
end

% Index vector
tic
[i1, i2, i3, i4, i5, i6, i7] = IndexVector2(n, size_u);
toc

% Solve
C = 9.0;
u = zeros(size_u, 1);
disp(' ');
tic
[u, Err] = NewtonMethod(u, C, n, i1, i2, i3, i4, i5, i6, i7);
toc

% Getting the full solution
p = 1;
v = zeros(n/2, n/2, n/2);
for i = 1:n/2
    for j = i:n/2
        for k = j:n/2
            v(i,j,k) = u(p);
            v(i,k,j) = u(p);
            v(j,i,k) = u(p);
            v(j,k,i) = u(p);
            v(k,i,j) = u(p);
            v(k,j,i) = u(p);
            p = p + 1;
        end
    end
end

u = zeros(n+1, n+1, n+1);
m = n/2+1;
a = 2:m;
b = n:-1:m;
u(a,a,a) = v;
u(a,a,b) = v;
u(a,b,a) = v;
u(b,a,a) = v;
u(a,b,b) = v;
u(b,a,b) = v;
u(b,b,a) = v;
u(b,b,b) = v;

% For easier, plotting in 1D
figure
plot(reshape(u, (n+1)^3, 1))

% Plotting u(x, 0.5, 0.5)
figure
plot((0:h:1), u(:,m,m))