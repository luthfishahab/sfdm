function [i1, i2, i3, i4, i5, i6, i7] = IndexVector2(n, size_u)
    A = zeros(size_u, 4);
    p = 0;
    for i = 1:n/2
        for j = i:n/2
            for k = j:n/2
                p = p + 1;
                A(p,1) = i;
                A(p,2) = j;
                A(p,3) = k;
                A(p,4) = i*10^6+j*10^3+k;
            end
        end
    end

    % Create Map M
    b = [1:size_u]';
    M = containers.Map(A(:,4),b);
    
    % 3-point stencil index
    i1 = zeros(size_u,1);
    i2 = zeros(size_u,1);
    i3 = zeros(size_u,1);
    i4 = zeros(size_u,1);
    i5 = zeros(size_u,1);
    i6 = zeros(size_u,1);
    i7 = zeros(size_u,1);
    p = 0;
    for i = 1:n/2
        disp(['i = ', num2str(i)])
        for j = i:n/2
            for k = j:n/2
                p = p + 1;
                
                % Find index i,j,k
                temp = i*10^6+j*10^3+k;
                index = M(temp);
                i1(p) = index;
    
                % Find index i+1,j,k
                a = i+1;
                b = j;
                c = k;
                a = min([a n-a]);
                b = min([b n-b]);
                c = min([c n-c]);
                d = sort([a b c]);
                a = d(1);
                b = d(2);
                c = d(3);
                if a ~= 0 && b ~= 0 && c ~= 0
                    temp = a*10^6+b*10^3+c;
                    index = M(temp);
                    i2(p) = index;
                else
                    i2(p) = size_u+1;
                end
    
                % Find index i-1,j,k
                a = i-1;
                b = j;
                c = k;
                a = min([a n-a]);
                b = min([b n-b]);
                c = min([c n-c]);
                d = sort([a b c]);
                a = d(1);
                b = d(2);
                c = d(3);
                if a ~= 0 && b ~= 0 && c ~= 0
                    temp = a*10^6+b*10^3+c;
                    index = M(temp);
                    i3(p) = index;
                else
                    i3(p) = size_u+1;
                end
    
                % Find index i,j+1,k
                a = i;
                b = j+1;
                c = k;
                a = min([a n-a]);
                b = min([b n-b]);
                c = min([c n-c]);
                d = sort([a b c]);
                a = d(1);
                b = d(2);
                c = d(3);
                if a ~= 0 && b ~= 0 && c ~= 0
                    temp = a*10^6+b*10^3+c;
                    index = M(temp);
                    i4(p) = index;
                else
                    i4(p) = size_u+1;
                end
    
                % Find index i,j-1,k
                a = i;
                b = j-1;
                c = k;
                a = min([a n-a]);
                b = min([b n-b]);
                c = min([c n-c]);
                d = sort([a b c]);
                a = d(1);
                b = d(2);
                c = d(3);
                if a ~= 0 && b ~= 0 && c ~= 0
                    temp = a*10^6+b*10^3+c;
                    index = M(temp);
                    i5(p) = index;
                else
                    i5(p) = size_u+1;
                end
    
                % Find index i,j,k+1
                a = i;
                b = j;
                c = k+1;
                a = min([a n-a]);
                b = min([b n-b]);
                c = min([c n-c]);
                d = sort([a b c]);
                a = d(1);
                b = d(2);
                c = d(3);
                if a ~= 0 && b ~= 0 && c ~= 0
                    temp = a*10^6+b*10^3+c;
                    index = M(temp);
                    i6(p) = index;
                else
                    i6(p) = size_u+1;
                end
    
                % Find index i,j,k-1
                a = i;
                b = j;
                c = k-1;
                a = min([a n-a]);
                b = min([b n-b]);
                c = min([c n-c]);
                d = sort([a b c]);
                a = d(1);
                b = d(2);
                c = d(3);
                if a ~= 0 && b ~= 0 && c ~= 0
                    temp = a*10^6+b*10^3+c;
                    index = M(temp);
                    i7(p) = index;
                else
                    i7(p) = size_u+1;
                end
            end
        end
    end
end