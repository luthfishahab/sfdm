clc
clear
close all

%% Figure 1

figure

A = readmatrix('Bifurcation Karkowski.xlsx');
x = A(:,1);
y = A(:,2);
plot(x, y, "LineWidth", 1.5)
hold on

A = readmatrix('Bifurcation McGough.csv');
x = A(:,1);
y = A(:,2);
plot(x, y, "LineWidth", 1.5, "LineStyle", "-.")
hold on

A = readmatrix('Bifurcation Temimi.csv');
x = A(:,1);
y = A(:,2);
plot(x, y, "LineWidth", 1.5, "LineStyle", "--")
hold on

A = readmatrix('Bifurcation Iqbal.csv');
x = A(:,1);
y = A(:,2);
plot(x, y, "LineWidth", 1.5, "LineStyle", ":")
hold on

A = readmatrix('Bifurcation Liao.csv');
x = A(:,1);
y = A(:,2);
plot(x, y, "LineWidth", 1.5, "LineStyle", ":")
hold on

x = [0.5 1 0.5 1];
y = [0.02867625 0.05855645 10.58986233 8.67456449];
scatter(x, y, "MarkerEdgeColor", "black", "LineWidth", 1.5)

legend('Karkowski', 'McGough', 'Temimi', 'Iqbal', 'Liao', 'Hajipour', "Location", "southwest")
xlabel('$\lambda$', 'Interpreter', 'latex')
ylabel('$||u||_{\infty}$', 'Interpreter', 'latex')

xlim([0 10])
ylim([0 12])
xticks(0:1:10)
yticks(0:1:12)
grid on

x0=100;
y0=100;
width=400;
height=300;
set(gcf,'position',[x0,y0,width,height])


%% Figure 2

figure

A = readmatrix('all_C_and_u_max FD n=20.csv');
x = A(:,1);
y = A(:,2);
plot(x, y, "LineWidth", 1.5)
hold on

A = readmatrix('Bifurcation Temimi.csv');
x = A(:,1);
y = A(:,2);
plot(x, y, "LineWidth", 1.5, "LineStyle", "--")
hold on

A = readmatrix('all_C_and_u_max FD n=31.csv');
x = A(:,1);
y = A(:,2);
plot(x, y, "LineWidth", 1.5, "LineStyle", "-.")
hold on

A = readmatrix('Bifurcation McGough.csv');
x = A(:,1);
y = A(:,2);
plot(x, y, "LineWidth", 1.5, "LineStyle", ":")

hold on

legend('SFDM n=20', 'Temimi', 'SFDM n=31', 'McGough')
xlabel('$\lambda$', 'Interpreter', 'latex')
ylabel('$||u||_{\infty}$', 'Interpreter', 'latex')

xlim([0 10])
ylim([0 12])
xticks(0:1:10)
yticks(0:1:12)
grid on

x0=100;
y0=100;
width=400;
height=300;
set(gcf,'position',[x0,y0,width,height])

%% Figure n=300 and past research and ball

figure

A = readmatrix('all_C_and_u_max FD n=300.csv');
x = [0; A(:,1)];
y = [0; A(:,2)];
plot(x, y, "LineWidth", 1.5)
max_old = max(x);

hold on
A = readmatrix('all_C_and_u_max FD d=3 n=1000000.csv');
x = [0; A(:,1)];
x = x*max_old/max(x);
y = [0; A(:,2)];
plot(x, y, "LineWidth", 1.5, "LineStyle", "--")

hold on
A = readmatrix('Bifurcation Karkowski.xlsx');
x = A(:,1);
y = A(:,2);
plot(x, y, "LineWidth", 1.5)

hold on
A = readmatrix('Bifurcation McGough.csv');
x = A(:,1);
y = A(:,2);
plot(x, y, "LineWidth", 1.5, "LineStyle", "-.")

hold on
A = readmatrix('Bifurcation Temimi.csv');
x = A(:,1);
y = A(:,2);
plot(x, y, "LineWidth", 1.5, "LineStyle", "--")

hold on
A = readmatrix('Bifurcation Iqbal.csv');
x = A(:,1);
y = A(:,2);
plot(x, y, "LineWidth", 1.5, "LineStyle", ":")
hold on

legend('SFDM n=300', 'FDM Ball n=10^6', 'Karkowski', 'McGough', 'Temimi', 'Iqbal', 'Location','southwest')
xlabel('$\lambda$', 'Interpreter', 'latex')
ylabel('$||u||_{\infty}$', 'Interpreter', 'latex')

xlim([0 10])
ylim([0 16])
xticks(0:1:10)
yticks(0:2:16)
grid on

x0=100;
y0=100;
width=400;
height=300;
set(gcf,'position',[x0,y0,width,height])

%% Figure n=20, ..., 300

figure

for n = 20:20:300
    file_name = "all_C_and_u_max FD n=" + num2str(n) + ".csv";
    A = readmatrix(file_name);
    x = [0; A(:,1)];
    y = [0; A(:,2)];
    plot(x, y, "LineWidth", 1)
    hold on
end

xlabel('$\lambda$', 'Interpreter', 'latex')
ylabel('$||u||_{\infty}$', 'Interpreter', 'latex')

xlim([0 10])
ylim([0 16])
xticks(0:1:10)
yticks(0:2:16)
grid on

x0=100;
y0=100;
width=400;
height=300;
set(gcf,'position',[x0,y0,width,height])

%% Figure n=290 and 300

figure

n = 300;
file_name = "all_C_and_u_max FD n=" + num2str(n) + ".csv";
A = readmatrix(file_name);
x = [0; A(:,1)];
y = [0; A(:,2)];
plot(x, y, "LineWidth", 1.5)
hold on
x300 = x;

n = 290;
file_name = "all_C_and_u_max FD n=" + num2str(n) + ".csv";
A = readmatrix(file_name);
x = [0; A(:,1)];
y = [0; A(:,2)];
plot(x, y, "LineWidth", 1.5, "LineStyle", "--")
hold on
x290 = x;

x = [0 10];
y = [10.5 10.5];
plot(x, y, 'black', "LineWidth", 1)

legend('SFDM n=300', 'SFDM n=290','Location','southwest')
xlabel('$\lambda$', 'Interpreter', 'latex')
ylabel('$||u||_{\infty}$', 'Interpreter', 'latex')

xlim([0 10])
ylim([0 16])
xticks(0:1:10)
yticks(0:2:16)
grid on

x0=100;
y0=100;
width=400;
height=300;
set(gcf,'position',[x0,y0,width,height])

err300and290 = abs(x300-x290);

%% Figure difference

figure
y = [0; A(:,2)];
plot(y, err300and290, "LineWidth", 1.5)

xlabel('$||u||_{\infty}$', 'Interpreter', 'latex')
ylabel('Difference', 'Interpreter', 'latex')

xlim([0 16])
% ylim([0 16])
xticks(0:2:16)
% yticks(0:2:16)
grid on

x0=100;
y0=100;
width=400;
height=300;
set(gcf,'position',[x0,y0,width,height])

%% Figure 1

h = 1/300;
x = [h:h:1]';
x = x(1:150);

figure

A = readmatrix('u_0_5_all_n=300.csv');
plot(x, A(:,1), "LineWidth", 1.5)
hold on
plot(x, A(:,2), "LineWidth", 1.5, "LineStyle", "--")
hold on
plot(x, A(:,3), "LineWidth", 1.5, "LineStyle", "--")
hold on
plot(x, A(:,4), "LineWidth", 1.5, "LineStyle", ":")
hold on
plot(x, A(:,5), "LineWidth", 1.5, "LineStyle", ":")
hold on
plot(x, A(:,6), "LineWidth", 1.5, "LineStyle", "--")

legend('1st Solution', '2nd Solution', '3rd Solution', '4th Solution', '5th Solution', '6th Solution', 'Location', 'northwest')
xlabel('$x$', 'Interpreter', 'latex')
ylabel('$u(x,0.5,0.5)$', 'Interpreter', 'latex')

% xlim([0.475 0.5])
% ylim([0 16])
% xticks(0:1:10)
% yticks(0:2:16)
grid on

x0=100;
y0=100;
width=400;
height=300;
set(gcf,'position',[x0,y0,width,height])

%% Figure 2

h = 1/300;
x = [h:h:1]';
x = x(1:150);

figure

A = readmatrix('u_0_5_all_n=300.csv');
plot(x, A(:,1), "LineWidth", 1.5)
hold on
plot(x, A(:,2), "LineWidth", 1.5, "LineStyle", "--")
hold on
plot(x, A(:,3), "LineWidth", 1.5, "LineStyle", "--")
hold on
plot(x, A(:,4), "LineWidth", 1.5, "LineStyle", ":", "Marker", "x")
hold on
plot(x, A(:,5), "LineWidth", 1.5, "LineStyle", ":", "Marker", "o")
hold on
plot(x, A(:,6), "LineWidth", 1.5, "LineStyle", "--", "Marker", "*")

legend('1st Solution', '2nd Solution', '3rd Solution', '4th Solution', '5th Solution', '6th Solution', 'Location', 'northwest')
xlabel('$x$', 'Interpreter', 'latex')
ylabel('$u(x,0.5,0.5)$', 'Interpreter', 'latex')

xlim([0.475 0.5])
% ylim([0 16])
% xticks(0:1:10)
% yticks(0:2:16)
grid on

x0=100;
y0=100;
width=400;
height=300;
set(gcf,'position',[x0,y0,width,height])

%% Figure 1

figure

A = readmatrix('all_C_and_u_max FD n=300.csv');
x = [0; A(:,1)];
y = [0; A(:,2)];
plot(x, y, "LineWidth", 1.5)
hold on
max_old = max(x);

A = readmatrix('all_C_and_u_max FD d=3 n=350.csv');
x = [0; A(:,1)];
x = x*max_old/max(x);
y = [0; A(:,2)];
plot(x, y, "LineWidth", 1.5, "LineStyle", "--")
hold on

legend('SFDM n=300', 'FDM Ball n=350','Location','southwest')
xlabel('$\lambda$', 'Interpreter', 'latex')
ylabel('$||u||_{\infty}$', 'Interpreter', 'latex')

xlim([0 10])
ylim([0 16])
xticks(0:1:10)
yticks(0:2:16)
grid on

x0=100;
y0=100;
width=400;
height=300;
set(gcf,'position',[x0,y0,width,height])

%% Figure 2

figure

A = readmatrix('all_C_and_u_max FD n=301.csv');
x = [0; A(:,1)];
y = [0; A(:,2)];
plot(x, y, "LineWidth", 1.5)
hold on
max_old = max(x);

A = readmatrix('all_C_and_u_max FD d=3 n=200.csv');
x = [0; A(:,1)];
x = x*max_old/max(x);
y = [0; A(:,2)];
plot(x, y, "LineWidth", 1.5, "LineStyle", "--")
hold on

legend('SFDM n=301', 'FDM Ball n=200','Location','southwest')
xlabel('$\lambda$', 'Interpreter', 'latex')
ylabel('$||u||_{\infty}$', 'Interpreter', 'latex')

xlim([0 10])
ylim([0 16])
xticks(0:1:10)
yticks(0:2:16)
grid on

x0=100;
y0=100;
width=400;
height=300;
set(gcf,'position',[x0,y0,width,height])

%% First Turning Point

A = readmatrix('all_C_and_u_max FD n=300 max_lambda.csv');
all_C = A(:, 1);
all_u_max = A(:, 2);

y2 = 1.5:0.000001:1.7;
x2 = spline(all_u_max(1:101), all_C(1:101), y2);
max_lambda = sprintf('%.9f', max(x2))