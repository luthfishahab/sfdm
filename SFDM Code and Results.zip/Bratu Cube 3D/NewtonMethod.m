function [u, Err] = NewtonMethod(u, C, n, i1, i2, i3, i4, i5, i6, i7)
    % Linear Operator
    L = LinearOperator(n, i1, i2, i3, i4, i5, i6, i7);

    % Maximum Iteration
    iter_max = 100;

    % Error
    Err = zeros(iter_max,1);

    % Newton Method Iteration
    for i = 1:iter_max
        u_old = u;
        F = Function(u, C, n, i1, i2, i3, i4, i5, i6, i7);
        J = Jacobian(u, C, n, L);
        y = J\(F);
        u = u - y;
        err = max(abs(u-u_old));
        Err(i) = err;

        disp(['Iteration = ', num2str(i), ', error = ', num2str(err)]); % Display
        
        if err < 1e-6
            break
        end
    end
    Err = Err(1:i);
end