function L = LinearOperator_u(n, i1, i2, i3, i4, i5, i6, i7, i8, i9)
    h = 1/n;
    
    size_u = size(i1,1);

    I = [i1 i2 i3 i4 i5 i6 i7 i8 i9];
    J = ones(size_u, 9);
    J(:,1) = -8*J(:,1);
    
    size_A = 0;
    for i = 1:size_u
        for j = 1:9
            if I(i,j) < size_u
                size_A = size_A + 1;
            end
        end
    end
    
    A = zeros(size_A+1, 3);
    p = 0;
    for i = 1:size_u
        for j = 1:9
            if I(i,j) < size_u
                p = p + 1;
                A(p,:) = [i I(i,j) J(i,j)];
            end
        end
    end
    p = p + 1;
    A(p,:) = [size_u size_u 0]; % square matrix
    
    L = sparse(A(:,1), A(:,2), A(:,3));
    L = L/h^2;
end