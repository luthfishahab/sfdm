function size_u = SizeU(n)
    size_u = 0;
    for i = 1:n/2
        for j = i:n/2
            for k = j:n/2
                for l = k:n/2
                    size_u = size_u + 1;
                end
            end
        end
    end
end