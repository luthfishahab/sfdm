clc
clear
close all

%% Figure n=10000 and ball

figure

A = readmatrix('all_C_and_u_max FD n=10000.csv');
x = [0; A(:,1)];
y = [0; A(:,2)];
plot(x, y, "LineWidth", 1.5)
max_old = max(x);

hold on
A = readmatrix('all_C_and_u_max FD d=2 n=1000000.csv');
x = [0; A(:,1)];
x = x*max_old/max(x);
y = [0; A(:,2)];
plot(x, y, "LineWidth", 1.5, "LineStyle", "--")

legend('SFDM n=10^4', 'FDM Ball n=10^6' , 'Location', 'northeast')
xlabel('$\lambda$', 'Interpreter', 'latex')
ylabel('$||u||_{\infty}$', 'Interpreter', 'latex')

xlim([0 7])
ylim([0 20])
xticks(0:1:7)
yticks(0:2:20)
grid on

x0=100;
y0=100;
width=400;
height=300;
set(gcf,'position',[x0,y0,width,height])

%% First Turning Point

A = readmatrix('all_C_and_u_max FD n=10000 max_lambda.csv');
all_C = A(:, 1);
all_u_max = A(:, 2);

y2 = 1.3:0.000001:1.5;
x2 = spline(all_u_max(1:101), all_C(1:101), y2);
max_lambda = sprintf('%.9f', max(x2))