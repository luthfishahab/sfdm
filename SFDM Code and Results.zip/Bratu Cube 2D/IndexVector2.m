function [i1, i2, i3, i4, i5] = IndexVector2(n, size_u)
    A = zeros(size_u, 3);
    p = 0;
    for i = 1:n/2
        for j = i:n/2
            p = p + 1;
            A(p,1) = i;
            A(p,2) = j;
            A(p,3) = i*10^4+j;
        end
    end

    % Create Map M
    b = [1:size_u]';
    M = containers.Map(A(:,3),b);
    
    % 3-point stencil index
    i1 = zeros(size_u,1);
    i2 = zeros(size_u,1);
    i3 = zeros(size_u,1);
    i4 = zeros(size_u,1);
    i5 = zeros(size_u,1);
    p = 0;
    for i = 1:n/2
        disp(['i = ', num2str(i)])
        for j = i:n/2
                p = p + 1;
                
                % Find index i,j
                temp = i*10^4+j;
                index = M(temp);
                i1(p) = index;
    
                % Find index i+1,j
                a = i+1;
                b = j;
                a = min([a n-a]);
                b = min([b n-b]);
                d = sort([a b]);
                a = d(1);
                b = d(2);
                if a ~= 0 && b ~= 0
                    temp = a*10^4+b;
                    index = M(temp);
                    i2(p) = index;
                else
                    i2(p) = size_u+1;
                end
    
                % Find index i-1,j
                a = i-1;
                b = j;
                a = min([a n-a]);
                b = min([b n-b]);
                d = sort([a b]);
                a = d(1);
                b = d(2);
                if a ~= 0 && b ~= 0
                    temp = a*10^4+b;
                    index = M(temp);
                    i3(p) = index;
                else
                    i3(p) = size_u+1;
                end
    
                % Find index i,j+1
                a = i;
                b = j+1;
                a = min([a n-a]);
                b = min([b n-b]);
                d = sort([a b]);
                a = d(1);
                b = d(2);
                if a ~= 0 && b ~= 0
                    temp = a*10^4+b;
                    index = M(temp);
                    i4(p) = index;
                else
                    i4(p) = size_u+1;
                end
    
                % Find index i,j-1
                a = i;
                b = j-1;
                a = min([a n-a]);
                b = min([b n-b]);
                d = sort([a b]);
                a = d(1);
                b = d(2);
                if a ~= 0 && b ~= 0
                    temp = a*10^4+b;
                    index = M(temp);
                    i5(p) = index;
                else
                    i5(p) = size_u+1;
                end
        end
    end
end