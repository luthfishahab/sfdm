function [i1, i2, i3] = IndexVector(n, size_u)
    i1 = [1:size_u]';
    i2 = i1+1;
    i3 = i1-1;
    i3(1) = size_u + 2;
end