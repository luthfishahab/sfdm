clc
clear
close all

%% Figure d=1,...,10

figure

A = readmatrix('all_C_and_u_max FD d=1 n=1000000.csv');
x = [0; A(:,1)];
y = [0; A(:,2)];
plot(x, y, "LineWidth", 1.5)

hold on
A = readmatrix('all_C_and_u_max FD d=2 n=1000000.csv');
x = [0; A(:,1)];
y = [0; A(:,2)];
plot(x, y, "LineWidth", 1.5)

hold on
A = readmatrix('all_C_and_u_max FD d=3 n=1000000.csv');
x = [0; A(:,1)];
y = [0; A(:,2)];
plot(x, y, "LineWidth", 1.5)

hold on
A = readmatrix('all_C_and_u_max FD d=4 n=1000000.csv');
x = [0; A(:,1)];
y = [0; A(:,2)];
plot(x, y, "LineWidth", 1.5)

hold on
A = readmatrix('all_C_and_u_max FD d=5 n=1000000.csv');
x = [0; A(:,1)];
y = [0; A(:,2)];
plot(x, y, "LineWidth", 1.5)

hold on
A = readmatrix('all_C_and_u_max FD d=6 n=1000000.csv');
x = [0; A(:,1)];
y = [0; A(:,2)];
plot(x, y, "LineWidth", 1.5)

hold on
A = readmatrix('all_C_and_u_max FD d=7 n=1000000.csv');
x = [0; A(:,1)];
y = [0; A(:,2)];
plot(x, y, "LineWidth", 1.5)

hold on
A = readmatrix('all_C_and_u_max FD d=8 n=1000000.csv');
x = [0; A(:,1)];
y = [0; A(:,2)];
plot(x, y, "LineWidth", 1.5)

hold on
A = readmatrix('all_C_and_u_max FD d=9 n=1000000.csv');
x = [0; A(:,1)];
y = [0; A(:,2)];
plot(x, y, "LineWidth", 1.5)

hold on
A = readmatrix('all_C_and_u_max FD d=10 n=1000000.csv');
x = [0; A(:,1)];
y = [0; A(:,2)];
plot(x, y, "LineWidth", 1.5)

% legend('FDM Ball 1D', 'FDM Ball 2D' , 'Location', 'northeastoutside')
xlabel('$\lambda$', 'Interpreter', 'latex')
ylabel('$||u||_{\infty}$', 'Interpreter', 'latex')

xlim([0 18])
ylim([0 20])
xticks(0:2:18)
yticks(0:2:20)
grid on

x0=100;
y0=100;
width=400;
height=300;
set(gcf,'position',[x0,y0,width,height])

%% Figure 2

figure

for n = 40:40:600
    file_name = "all_C_and_u_max FD d=3 n=" + num2str(n) + ".csv";
    A = readmatrix(file_name);
    x = [0; A(:,1)];
    y = [0; A(:,2)];
    plot(x, y, "LineWidth", 1)
    hold on
end

xlabel('$\lambda$', 'Interpreter', 'latex')
ylabel('$||u||_{\infty}$', 'Interpreter', 'latex')

xlim([0 3.4])
ylim([0 18])
xticks(0:0.5:3.5)
yticks(0:2:20)
grid on

x0=100;
y0=100;
width=400;
height=300;
set(gcf,'position',[x0,y0,width,height])