function F = Function(u, C, n, i1, i2, i3, d, x)
    h = 1/n;
    
    U = [u; 0; u(1)];

    if d == 1
        u_xx = (-2*U(i1) + U(i2) + U(i3))/(h^2);
        F = u_xx + C*exp(U(i1));
    else
        u_xx = (-2*U(i1) + U(i2) + U(i3))/(h^2);
        u_x = (U(i2) - U(i3))/(2*h);
        F = u_xx + (d-1)*u_x./x + C*exp(U(i1));
    end
end