clc
clear
close all

% Parameter
d = 3; % choose: 1, 2, 3, ..., 10
n = 600; 
h = 1/n;
x = [h:h:1-h]';

% Size of u
size_u = n-1;

% Index vector
tic
[i1, i2, i3] = IndexVector(n, size_u);
toc

% Solve
size_bifurcation = 300;
all_C = zeros(size_bifurcation, 1);
all_u_max = zeros(size_bifurcation, 1);

% Initial Values
u_and_C = zeros(size_u, 1);

j = 1;
for i = 0.1 : 0.1 : 30
    u_max = i;
    disp(' ');
    disp(['u_max = ', num2str(u_max)])

    tic
    [u_and_C, Err, F, L, J, y] = NewtonMethod_u(u_and_C, u_max, n, i1, i2, i3, d, x);
    toc
    
        C = u_and_C(1);
        u = u_and_C;
        u(1) = u_max;
    
    all_C(j) = C;
    all_u_max(j) = u_max;

    j = j + 1;
end

filename1 = "all_C_and_u_max FD d=" + d + " n=" + n + ".csv";
writematrix([all_C all_u_max], filename1, 'Delimiter', ';');

figure
plot([0; all_C], [0; all_u_max])