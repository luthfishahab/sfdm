function J = Jacobian_u(u, C, n, L)
    size_u = size(u,1);

    % Nonlinear Operator
    A = zeros(size_u-1, 3);
    for i = 2:size_u
        A(i-1, :) = [i i C*exp(u(i))];
    end

    B = zeros(size_u, 3);
    for i = 1:size_u
        B(i, :) = [i 1 exp(u(i))];
    end

    A = [A; B];

    J = sparse(A(:,1), A(:,2), A(:,3));
    
    % Jacobian = Linear Operator + Nonlinear Operator
    J = L + J;
end