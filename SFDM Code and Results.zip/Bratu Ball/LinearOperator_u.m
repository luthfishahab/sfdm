function L = LinearOperator_u(n, i1, i2, i3, d, x)
    h = 1/n;
    
    size_u = size(i1,1);

    I = [i1 i2 i3];
    J = ones(size_u,3)/(h^2);
    J(:,1) = -2*J(:,1);
    K = ones(size_u,3)/(2*h);
    K = (d-1)*K./x;
    K(:,1) = K(:,1)*0;
    K(:,3) = -K(:,3);
    
    size_A = 0;
    for i = 1:size_u
        for j = 1:3
            if I(i,j) <= size_u && I(i,j) > 1
                size_A = size_A + 1;
            end
        end
    end
    
    A = zeros(size_A, 3);
    p = 0;
    for i = 1:size_u
        for j = 1:3
            if I(i,j) <= size_u && I(i,j) > 1
                p = p + 1;
                A(p,:) = [i I(i,j) J(i,j)+K(i,j)];
            end
        end
    end
    
    L = sparse(A(:,1), A(:,2), A(:,3));
end