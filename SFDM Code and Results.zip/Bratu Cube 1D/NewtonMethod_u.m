function [u_and_C, Err] = NewtonMethod_u(u_and_C, u_max, n, i1, i2, i3)
    % Linear Operator
    L = LinearOperator_u(n, i1, i2, i3);

    % Maximum Iteration
    iter_max = 15;

    % Error
    Err = zeros(iter_max,1);

    % Newton Method Iteration
    for i = 1:iter_max
        u_and_C_old = u_and_C;

        C = u_and_C(end);
        u = u_and_C;
        u(end) = u_max;

        F = Function(u, C, n, i1, i2, i3);
        J = Jacobian_u(u, C, n, L);
        y = J\(F);
        u_and_C = u_and_C - y;
        err = max(abs(u_and_C-u_and_C_old));
        Err(i) = err;

        disp(['Iteration = ', num2str(i), ', error = ', num2str(err)]); % Display

        if err < 1e-6
            break
        end
    end
    Err = Err(1:i);

        % Repeat if it does not converge
        if i == iter_max
                % Zero Solution
                u_and_C = u_and_C*0;
        
                % Error
                Err = zeros(iter_max,1);
            
                % Newton Method Iteration
                for i = 1:iter_max
                    u_and_C_old = u_and_C;
            
                    C = u_and_C(end);
                    u = u_and_C;
                    u(end) = u_max;
            
                    F = Function(u, C, n, i1, i2, i3);
                    J = Jacobian_u(u, C, n, L);
                    y = J\(F);
                    u_and_C = u_and_C - y;
                    err = max(abs(u_and_C-u_and_C_old));
                    Err(i) = err;
            
                    disp(['Iteration = ', num2str(i), ', error = ', num2str(err)]); % Display
            
                    if err < 1e-6
                        break
                    end
                end
                Err = Err(1:i);
        end
end