clc
clear
close all

%% Figure n=10000 and ball

figure

A = readmatrix('all_C_and_u_max FD n=100000000.csv');
x = [0; A(:,1)];
y = [0; A(:,2)];
plot(x, y, "LineWidth", 1.5)

hold on
A = readmatrix('all_C_and_u_max FD d=1 n=1000000.csv');
x = [0; A(:,1)];
max_old_per_max_x = 4;
x = x*max_old_per_max_x;
y = [0; A(:,2)];
plot(x, y, "LineWidth", 1.5, "LineStyle", "--")

legend('SFDM n=10^8', 'FDM Ball n=10^6' , 'Location', 'northeast')
xlabel('$\lambda$', 'Interpreter', 'latex')
ylabel('$||u||_{\infty}$', 'Interpreter', 'latex')

xlim([0 4])
ylim([0 20])
xticks(0:0.5:4)
yticks(0:2:20)
grid on

x0=100;
y0=100;
width=400;
height=300;
set(gcf,'position',[x0,y0,width,height])

%% First Turning Point

A = readmatrix('all_C_and_u_max FD n=100000000 max_lambda.csv');
all_C = A(:, 1);
all_u_max = A(:, 2);

y2 = 1.1:0.000001:1.3;
x2 = spline(all_u_max(1:101), all_C(1:101), y2);
max_lambda = sprintf('%.9f', max(x2))