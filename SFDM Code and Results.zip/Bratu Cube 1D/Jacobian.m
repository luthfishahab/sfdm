function J = Jacobian(u, C, n, L)
    size_u = size(u,1);

    % Nonlinear Operator
    A = zeros(size(u,1), 3);
    for i = 1:size_u
        A(i, :) = [i i C*exp(u(i))];
    end

    J = sparse(A(:,1), A(:,2), A(:,3));
    
    % Jacobian = Linear Operator + Nonlinear Operator
    J = L + J;
end