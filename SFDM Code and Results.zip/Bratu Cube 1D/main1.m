clc
clear
close all

% Parameter
n = 10^2; % choose: 10^2, 10^3, 10^4, 10^5, 10^6, 10^7, 10^8
h = 1/n;

% Size of u
size_u = 0;
for i = 1:n/2
    size_u = size_u + 1;
end

% Index vector
tic
[i1, i2, i3] = IndexVector(n, size_u);
toc
    
% Solve
C = 3;
u = zeros(size_u, 1);
disp(' ');
tic
[u, Err] = NewtonMethod(u, C, n, i1, i2, i3);
toc

% Getting the full solution
u = [0; u; u(end-1:-1:1); 0];

% Plotting
figure
plot((0:h:1), u)