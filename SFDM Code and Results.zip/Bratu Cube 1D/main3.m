clc
clear
close all

% Parameter
n = 10^2; % choose: 10^2, 10^3, 10^4, 10^5, 10^6, 10^7, 10^8
h = 1/n;

% Size of u
size_u = 0;
for i = 1:n/2
    size_u = size_u + 1;
end

% Index vector
tic
[i1, i2, i3] = IndexVector(n, size_u);
toc

% Solve
size_bifurcation = 101;
all_C = zeros(size_bifurcation, 1);
all_u_max = zeros(size_bifurcation, 1);

% Initial Values
u_and_C = zeros(size_u, 1);

j = 1;
for i = 1.1 : 0.2/100 : 1.3
    u_max = i;
    disp(' ');
    disp(['u_max = ', num2str(u_max)])

    tic
    [u_and_C, Err] = NewtonMethod_u(u_and_C, u_max, n, i1, i2, i3);
    toc
    
        C = u_and_C(end);
        u = u_and_C;
        u(end) = u_max;
    
    all_C(j) = C;
    all_u_max(j) = u_max;

    j = j + 1;
end

filename1 = "all_C_and_u_max FD n=" + n + " max_lambda.csv";
writematrix([all_C all_u_max], filename1, 'Delimiter', ';');

y2 = 1.1:0.000001:1.3;
x2 = spline(all_u_max(1:101), all_C(1:101), y2);
max_lambda = sprintf('%.9f', max(x2))